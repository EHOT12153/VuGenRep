Action()
{
	lr_start_transaction("UC_CheckItinerary");

/*Correlation comment - Do not change!  Original value='136368.564277035HAVttfipAcftcAizpHtiVf' Name ='userSession' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=userSession",
		"TagName=input",
		"Extract=value",
		"Name=userSession",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/nav.pl*",
		LAST);
		
		lr_start_transaction("LoginPage");
		
		
web_reg_find("Text=Web Tours",
		LAST);
		
		
	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(13);
	
	lr_end_transaction("LoginPage",LR_AUTO);

	lr_start_transaction("login");
	
	web_reg_find("Text=Welcome, <b>{login}</b>, to the Web Tours reservation pages",LAST);

	web_submit_data("login.pl",
		"Action=http://localhost:1080/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=body",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t2.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value={login}", ENDITEM,
		"Name=password", "Value={password}", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		"Name=login.x", "Value=59", ENDITEM,
		"Name=login.y", "Value=0", ENDITEM,
		LAST);

	lr_end_transaction("login",LR_AUTO);

	lr_think_time(16);

	

	lr_start_transaction("CheckItinerary");
	
	web_reg_find("Text={firstname} {lastname}",LAST);

	web_url("Itinerary Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("CheckItinerary",LR_AUTO);

	lr_think_time(23);

	lr_start_transaction("SignOff");
	
	web_reg_find("Text=Web Tours",
		LAST);

	web_url("SignOff Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("SignOff",LR_AUTO);

	lr_end_transaction("UC_CheckItinerary", LR_AUTO);

	return 0;
}