Action()
{
	web_set_max_html_param_len("99999999");

	lr_start_transaction("UC_DeleteTicket");

/*Correlation comment - Do not change!  Original value='136363.35471851HAVtVQApAfiDDDDDtcAifpVtADf' Name ='userSession' Type ='ResponseBased'*/
	web_reg_save_param_attrib(
		"ParamName=userSession",
		"TagName=input",
		"Extract=value",
		"Name=userSession",
		"Type=hidden",
		SEARCH_FILTERS,
		"IgnoreRedirections=No",
		"RequestUrl=*/nav.pl*",
		LAST);

	web_reg_find("Text=Web Tours Navigation Bar",
		LAST);

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	

	lr_think_time(10);

	lr_start_transaction("login");
	

	web_reg_find("Text=Welcome, <b>{login}</b>, to the Web Tours reservation pages.",
		LAST);

	

	web_submit_data("login.pl",
		"Action=http://localhost:1080/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=body",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t2.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession}", ENDITEM,
		"Name=username", "Value={login}", ENDITEM,
		"Name=password", "Value={password}", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		"Name=login.x", "Value=42", ENDITEM,
		"Name=login.y", "Value=2", ENDITEM,
		LAST);

	lr_end_transaction("login",LR_AUTO);

	lr_start_transaction("Itinenrary_tray");
	

	web_reg_find("Text={firstname} {lastname}",LAST);

	

	web_reg_save_param("flightID",
		"LB=flightID\" value=\"",
		"RB=\"",
		LAST);
	
//	web_reg_save_param("checkbox",
//		"LB=checkbox\"name=\"",
//		"RB=\"",
//		"Ord=ALL",
//		LAST);

	

	web_url("Itinerary Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);
	
//	lr_save_string(lr_paramarr_random("checkbox"), "random_checkbox");
//	lr_save_string(lr_paramarr_idx("flightID", atoi(lr_paramarr_random("checkbox"))), " randomflightID");


	lr_end_transaction("Itinenrary_tray",LR_AUTO);

	lr_think_time(35);

	lr_start_transaction("delete_ticket");
	

	

	web_reg_find("Fail=Found",
		"Text=randomflightID",
		LAST);

	
	
	web_submit_form("itinerary.pl", 
		"Snapshot=t8.inf", 
		ITEMDATA, 
		"Name=1", "Value=on", ENDITEM, 
		 "Name=removeFlights.x", "Value=33", ENDITEM, 
		"Name=removeFlights.y", "Value=6", ENDITEM, 
		LAST);

	lr_end_transaction("delete_ticket",LR_AUTO);

	lr_think_time(28);

	lr_start_transaction("sign_off");

	web_reg_find("Text=Web Tours Navigation Bar",
		LAST);

	web_url("SignOff Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("sign_off",LR_AUTO);
	
	lr_end_transaction("UC_DeleteTicket", LR_AUTO);

	return 0;
}